import React from 'react';

import {SafeAreaView, View, Text} from 'react-native';

const Appearance = () => {
  return (
    <SafeAreaView>
      <View>
        <Text>Appearance</Text>
      </View>
    </SafeAreaView>
  );
};

export default Appearance;
