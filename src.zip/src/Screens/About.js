import React from 'react';
import {StyleSheet, Text, View} from 'react-native';

const About = () => {
  return (
    <View>
      <Text>Welcome About</Text>
    </View>
  );
};

const styles = StyleSheet.create({});
export default About;
