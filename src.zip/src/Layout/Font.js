export default {
  LatoBlack: 'Lato-Black',
  LatoBlackItalic: 'Lato-BlackItalic',
  LatoBold: 'Lato-Bold',
  LatoBoldItalic: 'Lato-BoldItalic',
  LatoLight: 'Lato-Light',
  LatoLightItalic: 'Lato-LightItalic',
  LatoRegular: 'Lato-Regular',
  LatoItalic: 'Lato-Italic',
  LatoThin: 'Lato-Thin',
  LatoThinItalic: 'Lato-ThinItalic',
};
